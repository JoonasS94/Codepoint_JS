-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 31.10.2024 klo 12:13
-- Palvelimen versio: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tilavaraus`
--
CREATE DATABASE IF NOT EXISTS `tilavaraus` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `tilavaraus`;

-- --------------------------------------------------------

--
-- Rakenne taululle `tilat`
--

CREATE TABLE `tilat` (
  `id` int(11) NOT NULL,
  `tilan_nimi` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Vedos taulusta `tilat`
--

INSERT INTO `tilat` (`id`, `tilan_nimi`) VALUES
(1, 'Impivaara'),
(2, 'Kupittaa'),
(3, 'Hovigym');

-- --------------------------------------------------------

--
-- Rakenne taululle `varaajat`
--

CREATE TABLE `varaajat` (
  `id` int(11) NOT NULL,
  `varaajan_nimi` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Vedos taulusta `varaajat`
--

INSERT INTO `varaajat` (`id`, `varaajan_nimi`) VALUES
(1, 'Joonas Sariola'),
(2, 'Matti Meikäläinen'),
(3, 'Maija Meikäläinen');

-- --------------------------------------------------------

--
-- Rakenne taululle `varaukset`
--

CREATE TABLE `varaukset` (
  `id` int(11) NOT NULL,
  `tila` int(11) NOT NULL,
  `varaaja` int(11) NOT NULL,
  `varauspaiva` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Vedos taulusta `varaukset`
--

INSERT INTO `varaukset` (`id`, `tila`, `varaaja`, `varauspaiva`) VALUES
(1, 1, 1, '2024-10-31'),
(2, 2, 2, '2024-10-08'),
(3, 3, 3, '2024-01-09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tilat`
--
ALTER TABLE `tilat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `varaajat`
--
ALTER TABLE `varaajat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `varaukset`
--
ALTER TABLE `varaukset`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tila` (`tila`),
  ADD KEY `varaaja` (`varaaja`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tilat`
--
ALTER TABLE `tilat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `varaajat`
--
ALTER TABLE `varaajat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `varaukset`
--
ALTER TABLE `varaukset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Rajoitteet vedostauluille
--

--
-- Rajoitteet taululle `varaukset`
--
ALTER TABLE `varaukset`
  ADD CONSTRAINT `varaukset_ibfk_1` FOREIGN KEY (`tila`) REFERENCES `tilat` (`id`),
  ADD CONSTRAINT `varaukset_ibfk_2` FOREIGN KEY (`varaaja`) REFERENCES `varaajat` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
